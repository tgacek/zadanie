
# tests/bench/

Various manually executed scripts to aid benchmarking, or trigger old
performance problems.
