#!/usr/bin/env python

import os
import pprint

pprint.pprint(dict(os.environ))
