# I am a dummy ansible.py, that would cause 'import ansible' to fail to trigger
# the Mitogen module loader prior to issue #109. I don't need to contain
# anything, I just need to exist on PYTHONPATH.
