# This is a placeholder so Ansible 2.3 can detect the corresponding action
# plug-in.
