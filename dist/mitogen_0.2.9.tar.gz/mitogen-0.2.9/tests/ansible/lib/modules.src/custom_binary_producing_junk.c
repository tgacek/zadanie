#include <stdio.h>


int main(void)
{
    fprintf(stderr, "binary_producing_junk: oh noes\n");
    printf("Hello, world.\n");
    return 0;
}
