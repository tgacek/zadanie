
def path():
    return 'ansible/lib/module_utils/externalpkg/extmod.py'
