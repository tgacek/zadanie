
def path():
    return "ansible/lib/module_utils/external2.py"
