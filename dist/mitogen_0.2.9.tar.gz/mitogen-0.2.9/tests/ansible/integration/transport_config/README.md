
# Tests for correct selection of connection variables.

This directory is a placeholder for a work-in-progress test set that tries
every combination of the variables extracted via `transport_config.py`.

In the meantime, it has ad-hoc scripts for bugs already encountered.
