
def path():
    return "integration/module_utils/roles/modrole/module_utils/external2.py"
