#!/usr/bin/env python
# Mainly for use in stubconnections/kubectl.yml

print('PID: 1')
