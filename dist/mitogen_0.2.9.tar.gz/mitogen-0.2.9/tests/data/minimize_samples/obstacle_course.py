#!python
# coding : utf-8
# comment
"docstring"

import sys

"cc", {}

def f1(a, b= None, c=[]): # comment
 r"""docstring
 """
 x = ""		
 print(
 a,  
    
b,
 """arg1""", # comment
"""arg2""", # comment
 c )  
 # comment
 'foo' > sys.stderr
 "baz"
#comment
 sys.stdout;lambda: "justastring"

1j

def f2():
    # comment
    '''docstring'''
    pass
class c:
    
    u'''docstring'''

    
    f='justastring'
    b'''docstring
'''
@f1
class c2(object):
    'docstring'
    def __init__(self):
        "docstring"
        def inner(): pass
        d = {'a':0}
        for x in '': # FIXME Removing this leaves nothing, hence a SyntaxError
            "justastring"
