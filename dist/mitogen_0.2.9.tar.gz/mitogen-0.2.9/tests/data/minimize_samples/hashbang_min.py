#/usr/bin/python -c
# coding: utf-8

