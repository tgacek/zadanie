class C:



 def method(self):


  pass
