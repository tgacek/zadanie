

def ping(*args):
    return args


