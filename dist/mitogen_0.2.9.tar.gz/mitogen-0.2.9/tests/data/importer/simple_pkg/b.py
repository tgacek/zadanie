
def subtract_one(n):
    return n - 1
