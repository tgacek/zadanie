
from __future__ import absolute_import
from module_finder_testmod.regular_mod import say_hi
