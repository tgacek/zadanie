

# doas-debian.tar.gz

A dynamically linked copy of the OpenBSD ``doas`` tool for Debian, port is from
https://github.com/multiplexd/doas (the slicer69 port is broken, it reads the
password from stdin).
